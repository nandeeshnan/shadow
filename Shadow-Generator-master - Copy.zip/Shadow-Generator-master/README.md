## Css Shadow Generator

### Preview :

<img width="1420" alt="Screen Shot 1401-03-17 at 02 18 12" src="https://user-images.githubusercontent.com/71524940/172254928-ddd68f45-6a8a-4c1e-95f8-151e232f50b5.png">
